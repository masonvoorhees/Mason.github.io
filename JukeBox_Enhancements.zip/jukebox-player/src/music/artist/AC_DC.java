package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class AC_DC {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public AC_DC() {
    }
    
    public ArrayList<Song> getAC_DCSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 

		 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("Rock", "Pop ACDC","https://www.youtube.com/watch?v=U_tyfMUSGo4");           				
         Song track2 = new Song("Thunderstruck", "ACDC","https://www.youtube.com/watch?v=v2AC41dglnM");                    				
         Song track3 = new Song("Back in Black", "ACDC","https://www.youtube.com/watch?v=pAgnJDJN4VA");   
         Song track4 = new Song("Highway to Hell", "ACDC","https://www.youtube.com/watch?v=IN0OcUvGb60");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                     //Return the songs for AC/DC in the form of an ArrayList
    }
}
