package music.artist;

import snhu.jukebox.playlist.Song;
import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URI;
import java.util.ArrayList;
//Created by Mason Voorhees
public class UserPlaylist {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public UserPlaylist() {
    }
    
    public ArrayList<Song> createAPlaylist() throws URISyntaxException {
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();
 		String command="";
 		try{
 			//loop until user adds all tracks to playlist end the loop if the user input is equal to "done"
 			while ( !command.toLowerCase().equals("done"))	
 			{
 				// ask user for the song title, artist, and link to the song
 				String title, artist, link;
 				System.out.println("\n\nPlease enter the title of the song");
 				BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
 				command = br1.readLine();
 				
 				//set user input equal to the title string
 				title = command;
 				System.out.println("Please the name of the artist");
 				br1 = new BufferedReader(new InputStreamReader(System.in));
 				command = br1.readLine();
 				
 				//set user input equal to the artist string
 				artist = command;
 				System.out.println("Please paste the link to the song");
 				br1 = new BufferedReader(new InputStreamReader(System.in));
 				command = br1.readLine();
 				
 				//set user input equal to the link string
 				link = command;
 				
 				// add title, artist, and link to song object and then add song to albumTacks
 				Song track = new Song(title,artist,link);
 				this.albumTracks.add(track);
 				System.out.println("The song has been added to your playlist!\n Press enter to add add another song. Type 'done' if your playlist is finished.");
 				br1 = new BufferedReader(new InputStreamReader(System.in));
 				command = br1.readLine();
 			}
 			
 		}
 		catch(Exception e){
 			System.out.println("Something went wrong with the system input!   Please try again.");
 		}
		 
         
         //Return the albumTracks array list
         return albumTracks;                                                  						  //Return the songs for the Pop Smoke in the form of an ArrayList
         
    }
}
