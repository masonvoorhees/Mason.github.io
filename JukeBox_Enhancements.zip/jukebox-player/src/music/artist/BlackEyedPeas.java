package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class BlackEyedPeas {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public BlackEyedPeas() {
    }
    
    public ArrayList<Song> getBlackEyedPeasSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("I Got A Feelin", "Black Eyed Peas","https://www.youtube.com/watch?v=uSD4vsh1zDA");           				
         Song track2 = new Song("Pump It", "Black Eyed Peas","https://www.youtube.com/watch?v=ZaI2IlHwmgQ");                    				
         Song track3 = new Song("Where Is The Love", "Black Eyed Peas","https://www.youtube.com/watch?v=WpYeekQkAdc");   
         Song track4 = new Song("Boom Boom Pow", "Black Eyed Peas","https://www.youtube.com/watch?v=4m48GqaOz90");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                        //Return the songs for the Black Eyed Peas in the form of an ArrayList
    }
}

