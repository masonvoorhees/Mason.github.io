package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class SZA {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public SZA() {
    }
    
    public ArrayList<Song> getSzaSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  

		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("I Hate You", "SZA","https://www.youtube.com/watch?v=xEAEDKzjQTY");           				
         Song track2 = new Song("All The Stars", "SZA","https://www.youtube.com/watch?v=JQbjS0_ZfJ0");                    				
         Song track3 = new Song("Good Days", "SZA","https://www.youtube.com/watch?v=2p3zZoraK9g");   
         Song track4 = new Song("No Love", "SZA","https://www.youtube.com/watch?v=IhSPyR72CqM");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                       //Return the songs for the Surfaces in the form of an ArrayList
    }
}
