package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class Kygo {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Kygo() {
    }
    
    public ArrayList<Song> getKygoSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 
		 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("It Aint Me", "Kygo","https://www.youtube.com/watch?v=u3VTKvdAuIY");           				
         Song track2 = new Song("Firestone", "Kygo","https://www.youtube.com/watch?v=9Sc-ir2UwGU");                    				
         Song track3 = new Song("Happy Now", "Kygo","https://www.youtube.com/watch?v=zaIsVnmwdqg");   
         Song track4 = new Song("Love Me Now", "Kygo","https://www.youtube.com/watch?v=rfxnmIPCzIc");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                     //Return the songs for the Kygo in the form of an ArrayList
    }
}
