package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class Surfaces {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Surfaces() {
    }
    
    public ArrayList<Song> getSurfacesSongs() throws URISyntaxException {
    	
    	//Create albumTrack array list to put all the songs into 
    	albumTracks = new ArrayList<Song>();  
    	
 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("Sunday Best", "Surfaces","https://www.youtube.com/watch?v=_83KqwEEGw4");             	
         Song track2 = new Song("Take It Easy", "Surfaces","https://www.youtube.com/watch?v=JJ63cfhD91U");         		
         Song track3 = new Song("Good Day", "Surfaces","https://www.youtube.com/watch?v=eNh5OraNPUs");    
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);											
         this.albumTracks.add(track2);                                        
         this.albumTracks.add(track3);      
         
         //Return the albumTracks array list
         return albumTracks;                                                   
    }
}
