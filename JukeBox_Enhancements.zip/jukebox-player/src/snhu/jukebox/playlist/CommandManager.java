package snhu.jukebox.playlist;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CommandManager {
	
	public CommandManager(){
	}
	
	// Method to print the main menu
	void printMainMenu(){
		System.out.println("\n\nWelcome to SNHU Jukebox Playlist Music!");
		System.out.println("Please enter one of the following playlists: \n - AnadaMagar_Playlist \n - MasonVoorhees_Playlist \n - PhilipEnkema_Playlist \n - TeslaSkeels_Playlist \n - TestStudent1_Playlist \n - TestStudent2_Playlist");
		System.out.println("Type 'Create' to create your own playlist");
		System.out.println("Quit: quit");
		System.out.print("Enter a Command : ");
	}
	//Gets user input and if the input does not match a playlist name, it asks again.
	String getCommand(){
		String command="";
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			command = br.readLine();
			while (!command.equals("AnandaMagar_Playlist") &&!command.equals("MasonVoorhees_Playlist") && !command.equals("PhilipEnkema_Playlist") && !command.equals("TeslaSkeels_Playlist") && !command.equals("TestStudent1_Playlist") && !command.equals("TestStudent2_Playlist") && !command.equals("Create") && !command.equals("quit"))
				
			{
				System.out.println("\n\nInvalid playlist name, please enter a playlist name from above.");
				System.out.print("Enter a Command : ");
				BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
				command = br1.readLine();
			}
			
		}
		catch(Exception e){
			System.out.println("Something went wrong with the system input!   Please try again.");
		}
		return command;
	}
	
	String parseCommand(String command){
		String studentPlaylistRequested ="";
		if(command!=null && command.length()>0){
			studentPlaylistRequested = command;
		}
		else{
			System.out.println("Please enter a valid command.");
		}
		return studentPlaylistRequested;
	}
}