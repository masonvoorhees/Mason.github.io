package snhu.jukebox.playlist;

import java.util.LinkedList;

public class Student {

	private String name;
	private LinkedList<PlayableSong> playlist;
	
	public Student(String name, LinkedList<PlayableSong> playlist) {
		this.name = name;
		this.playlist = playlist;
	}
	
	//Get student name
	public String getName() {
		return name;
	}
	
	//Set student name
	public void setName(String name) {
		this.name = name;
	}
	
	//Get playlist
	public LinkedList<PlayableSong> getPlaylist() {
		return playlist;
	}

	//Set playlist
	public void setPlaylist(LinkedList<PlayableSong> playlist) {
		this.playlist = playlist;
	}
}
