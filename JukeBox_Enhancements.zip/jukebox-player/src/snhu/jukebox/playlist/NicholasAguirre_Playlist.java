package snhu.jukebox.playlist;

import snhu.student.playlists.TeslaSkeels_Playlist;

public class NicholasAguirre_Playlist extends TeslaSkeels_Playlist {

}
