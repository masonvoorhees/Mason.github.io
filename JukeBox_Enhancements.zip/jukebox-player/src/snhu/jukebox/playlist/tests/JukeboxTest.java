package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import org.junit.Test;
import music.artist.*;
import snhu.jukebox.playlist.Song;

public class JukeboxTest {

	@Test
	public void testGetBeatlesAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 TheBeatles theBeatlesBand = new TheBeatles();
		 ArrayList<Song> beatlesTracks = new ArrayList<Song>();
		 beatlesTracks = theBeatlesBand.getBeatlesSongs();
		 assertEquals(2, beatlesTracks.size());
	}
	
	@Test
	public void testGetBlackEyedPeasAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 BlackEyedPeas blackEyedPeasBand = new BlackEyedPeas();
		 ArrayList<Song> blackEyedPeasTracks = new ArrayList<Song>();
		 blackEyedPeasTracks = blackEyedPeasBand.getBlackEyedPeasSongs();
		 assertEquals(2, blackEyedPeasTracks.size());
	}
	
	@Test
	public void testGetBTSAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 BTS bTSBand = new BTS();
		 ArrayList<Song> bTSTracks = new ArrayList<Song>();
		 bTSTracks = bTSBand.getBTSSongs();
		 assertEquals(3, bTSTracks.size());
	}
	
	@Test
	public void testGetImagineDragonsAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 ImagineDragons imagineDragons = new ImagineDragons();
		 ArrayList<Song> imagineDragonsTracks = new ArrayList<Song>();
		 imagineDragonsTracks = imagineDragons.getImagineDragonsSongs();
		 assertEquals(4, imagineDragonsTracks.size());  // corrected size error
	}
	
	@Test
	public void testGetAdelesAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 Adele adele = new Adele();
		 ArrayList<Song> adelesTracks = new ArrayList<Song>();
		 adelesTracks = adele.getAdelesSongs();
		 assertEquals(3, adelesTracks.size());
	}

	@Test
	public void testGetBurtBacharachAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException { // added by p.enkema
		 BurtBacharach burtBacharach = new BurtBacharach();
		 ArrayList<Song> burtBacharachTracks = new ArrayList<Song>();
		 burtBacharachTracks = burtBacharach.getBurtBacharachSongs();
		 assertEquals(3, burtBacharachTracks.size());
	}

	@Test
	public void testGetHerbAlpertAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {    // added by p.enkema
		 HerbAlpert herbAlpert = new HerbAlpert();
		 ArrayList<Song> herbAlpertTracks = new ArrayList<Song>();
		 herbAlpertTracks = herbAlpert.getHerbAlpertSongs();
		 assertEquals(2, herbAlpertTracks.size());
	}
	
	
	@Test
	public void PopSmokeAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {    // added by Mason Voorhees
		 PopSmoke popSmoke = new PopSmoke();
		 ArrayList<Song> popSmokeTracks = new ArrayList<Song>();
		 popSmokeTracks = popSmoke.getPopSmokeSongs();
		 assertEquals(3, popSmokeTracks.size());
	}
	
	//methods below were throwing errors, commented out to get code to run
	/*
	//Jeremy Camp album size test
	@Test
	public void testGetJeremyCampAlbumSize() throws NoSuchFieldException, SecurityException {    // added by t.smith
		JeremyCamp jeremyCamp = new JeremyCamp();
		 ArrayList<Song> jeremyCampTracks = new ArrayList<Song>();
		 jeremyCampTracks = jeremyCamp.getJeremyCampSongs();
		 assertEquals(5, jeremyCampTracks.size());
	}
	//MercyMe album size test
	@Test
	public void testGetMercyMeAlbumSize() throws NoSuchFieldException, SecurityException {    // added by t.smith
		MercyMe mercyMe = new MercyMe();
		 ArrayList<Song> mercyMeTracks = new ArrayList<Song>();
		 mercyMeTracks = mercyMe.getMercyMeSongs();
		 assertEquals(5, mercyMeTracks.size());
	}
	//Zach Williams album size test
	@Test
	public void testGetZachWilliamsAlbumSize() throws NoSuchFieldException, SecurityException {    // added by t.smith
		ZachWilliams zachWilliams = new ZachWilliams();
		 ArrayList<Song> zachWilliamsTracks = new ArrayList<Song>();
		 zachWilliamsTracks = zachWilliams.getZachWilliamsSongs();
		 assertEquals(5, zachWilliamsTracks.size());
	}
*/
	@Test
	public void testGetSzaAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 SZA sza = new SZA();
		 ArrayList<Song> szaTracks = new ArrayList<Song>();
		 szaTracks = sza.getSzaSongs();
		 assertEquals(2, szaTracks.size());
	}
	
	@Test
	public void testGetSurfacesAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException {
		 Surfaces surfaces = new Surfaces();
		 ArrayList<Song> surfacesTracks = new ArrayList<Song>();
		 surfacesTracks = surfaces.getSurfacesSongs();
		 assertEquals(3, surfacesTracks.size());
	}
	
	@Test
	public void testGetTomGrennanAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException { // added t.skeels
		 TomGrennan tomGrennan = new TomGrennan();
		 ArrayList<Song> tomGrennanTracks = new ArrayList<Song>();
		 tomGrennanTracks = tomGrennan.getTomGrennanSongs();
		 assertEquals(3, tomGrennanTracks.size());
	}
	
	@Test
	public void testGetFlorAlbumSize() throws NoSuchFieldException, SecurityException, URISyntaxException { // added t.skeels
		 Flor flor = new Flor();
		 ArrayList<Song> florTracks = new ArrayList<Song>();
		 florTracks = flor.getFlorSongs();
		 assertEquals(2, florTracks.size());
	}
	
}
