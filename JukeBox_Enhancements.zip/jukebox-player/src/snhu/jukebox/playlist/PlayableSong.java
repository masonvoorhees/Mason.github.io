package snhu.jukebox.playlist;
import java.net.URI;

public abstract class PlayableSong {
	    String title;
	    String artist;
	    URI songLink;
	    abstract void play();
	   
}
