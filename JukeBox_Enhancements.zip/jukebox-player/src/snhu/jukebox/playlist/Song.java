package snhu.jukebox.playlist;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;


public class Song extends PlayableSong {

	//Creating a song object
    public Song(String t, String a, String s) throws URISyntaxException {
        this.title = t;
        this.artist = a;
        this.songLink = new URI(s); 
    }
    
    //Print each song in user picked play list out by title and artist.
    @Override
    void play() {
        System.out.println("Now playing " + this.title + " by " + this.artist + ".");
        
        //Open song in YouTube
		Desktop desktop = java.awt.Desktop.getDesktop();
		
		try {
			
			//specify the protocol along with the URL
			desktop.browse(this.songLink);
		} 
		catch ( IOException e) {
	        System.out.println("An error occured while loading the song, skipping to next song");
		}	
	}	
}
