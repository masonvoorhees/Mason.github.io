package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

public class TestStudent1_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
	
	//Create a linked list called playlist of type PlayableSong
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	//an array lists of type song
	ArrayList<Song> beatlesTracks = new ArrayList<Song>();
	ArrayList<Song> imagineDragonsTracks = new ArrayList<Song>();
	
	//Instantiate all artist objects
	TheBeatles theBeatlesBand = new TheBeatles();
    ImagineDragons imagineDragonsBand = new ImagineDragons();
    
	//set Arraylists equal to all songs by that artist
    beatlesTracks = theBeatlesBand.getBeatlesSongs();
    imagineDragonsTracks = imagineDragonsBand.getImagineDragonsSongs();
	
    //add songs to the playlist 
    playlist.add(beatlesTracks.get(0));
	playlist.add(beatlesTracks.get(1));
	playlist.add(imagineDragonsTracks.get(0));
	playlist.add(imagineDragonsTracks.get(1));
	playlist.add(imagineDragonsTracks.get(2));
	
	//return the playlist 
    return playlist;
	}
}
