package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

public class PhilipEnkema_Playlist {
	/* added for module 6 requirements
	 * songs from Helb Alpert, Burt Bacharach, and Imagine Dragons
	 */
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
	
	//Create a linked list called playlist of type PlayableSong
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	// an array lists of type song
	ArrayList<Song> bacharachTracks = new ArrayList<Song>();
	ArrayList<Song> herbAlpertTracks = new ArrayList<Song>();
	ArrayList<Song> imagineDragonsTracks = new ArrayList<Song>();
	
	//Instantiate all artist objects
	BurtBacharach burtBacharach = new BurtBacharach();
	HerbAlpert herbAlpert = new HerbAlpert();
	ImagineDragons imagineDragonsBand = new ImagineDragons();

	//set Arraylists equal to all songs by that artist
	bacharachTracks = burtBacharach.getBurtBacharachSongs();
	herbAlpertTracks = herbAlpert.getHerbAlpertSongs();
    imagineDragonsTracks = imagineDragonsBand.getImagineDragonsSongs();
	
    //add songs to the playlist 
	playlist.add(herbAlpertTracks.get(0));
	playlist.add(herbAlpertTracks.get(1));
	playlist.add(bacharachTracks.get(0));
	playlist.add(bacharachTracks.get(1));
	playlist.add(bacharachTracks.get(2));
	playlist.add(imagineDragonsTracks.get(0));
	
	//return the playlist 
    return playlist;
	}
}
