package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

public class TeslaSkeels_Playlist {
	
	//added songs from Flor and TomGrennan
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException
	{
		//Create a linked list called playlist of type PlayableSong
		LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
		
		//an array lists of type song
		ArrayList<Song> florTracks = new ArrayList<Song>();
		ArrayList<Song> tomGrennanTracks = new ArrayList<Song>();
		
		//Instantiate all artist objects
	    Flor florBand = new Flor();	
	    TomGrennan tomGrennanBand = new TomGrennan();

		//set Arraylists equal to all songs by that artist
	    florTracks = florBand.getFlorSongs();
	    tomGrennanTracks = tomGrennanBand.getTomGrennanSongs();
	   
	    //add songs to the playlist 
		playlist.add(florTracks.get(0));
		playlist.add(florTracks.get(1));
		playlist.add(tomGrennanTracks.get(0));
		playlist.add(tomGrennanTracks.get(1));
		playlist.add(tomGrennanTracks.get(2));
		
		//return the playlist 
	    return playlist;
	}
	
}
