package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

public class TestStudent2_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
	
	//Create a linked list called playlist of type PlayableSong
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	//an array lists of type song
	ArrayList<Song> adeleTracks = new ArrayList<Song>();
   
	//Instantiate all artist objects
	Adele adele = new Adele();
	
	//set Arraylists equal to all songs by that artist
    adeleTracks = adele.getAdelesSongs();
	
    //add songs to the playlist 
	playlist.add(adeleTracks.get(0));
	playlist.add(adeleTracks.get(1));
	playlist.add(adeleTracks.get(2));
	
	//return the playlist 
    return playlist;
	}
}