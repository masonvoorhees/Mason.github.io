package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

public class AnandaMagar_Playlist {
	/* 
	 * songs from Black Eyed Peas and BTS
	 */
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
		
	//Create a linked list called playlist of type PlayableSong
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	// an array lists of type song
	ArrayList<Song> blackEyedPeasTracks = new ArrayList<Song>();
	ArrayList<Song> bTSTracks = new ArrayList<Song>();
	
	//Instantiate all artist objects
	BlackEyedPeas blackEyedPeas = new BlackEyedPeas();
	BTS bTS = new BTS();
	
	//set Arraylists equal to all songs by that artist
	blackEyedPeasTracks = blackEyedPeas.getBlackEyedPeasSongs();
	bTSTracks = bTS.getBTSSongs();
	
	//add songs to the playlist  
	
	playlist.add(blackEyedPeasTracks.get(0));
	playlist.add(blackEyedPeasTracks.get(1));	
	playlist.add(bTSTracks.get(0));
	playlist.add(bTSTracks.get(1));
	playlist.add(bTSTracks.get(2));
	
	//return the playlist 
    return playlist;
	}
}
