package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;
//Created by Mason Voorhees
public class MasonVoorhees_Playlist {
	/* added for module 6 requirements
	 * songs from PopSmoke, Surfaces, and Flor
	 */
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
		
	//Create a linked list called playlist of type PlayableSong
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	// an array lists of type song
	ArrayList<Song> PopSmokeTracks = new ArrayList<Song>();
	ArrayList<Song> surfacesTracks = new ArrayList<Song>();
	ArrayList<Song> FlorTracks = new ArrayList<Song>();
	
	//Instantiate all artist objects
	PopSmoke popSmoke = new PopSmoke();
	Surfaces surfaces = new Surfaces();
	Flor flor = new Flor();
	
	//set Array lists equal to all songs by that artist
	PopSmokeTracks = popSmoke.getPopSmokeSongs();
	surfacesTracks = surfaces.getSurfacesSongs();
	FlorTracks = flor.getFlorSongs();
	
	//add songs to the playlist  
	playlist.add(PopSmokeTracks.get(0));
	playlist.add(PopSmokeTracks.get(1));
	playlist.add(PopSmokeTracks.get(2));	
	playlist.add(surfacesTracks.get(0));
	playlist.add(surfacesTracks.get(2));
	playlist.add(FlorTracks.get(0));
	
	//return the playlist 
    return playlist;
	}
}
