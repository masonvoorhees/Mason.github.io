package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;
//Created by Mason Voorhees
public class MasonVoorhees_Playlist {
	/* added for module 6 requirements
	 * songs from PopSmoke, Surfaces, and Flor
	 */
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
		

	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	ArrayList<Song> PopSmokeTracks = new ArrayList<Song>();
	PopSmoke popSmoke = new PopSmoke();
	PopSmokeTracks = popSmoke.getPopSmokeSongs();
	playlist.add(PopSmokeTracks.get(0));
	playlist.add(PopSmokeTracks.get(1));
	playlist.add(PopSmokeTracks.get(2));
	ArrayList<Song> surfacesTracks = new ArrayList<Song>();
	Surfaces surfaces = new Surfaces();
	surfacesTracks = surfaces.getSurfacesSongs();
	playlist.add(surfacesTracks.get(0));
	playlist.add(surfacesTracks.get(2));
	ArrayList<Song> FlorTracks = new ArrayList<Song>();
	Flor flor = new Flor();
	FlorTracks = flor.getFlorSongs();
	playlist.add(FlorTracks.get(0));

    return playlist;
	}
}
