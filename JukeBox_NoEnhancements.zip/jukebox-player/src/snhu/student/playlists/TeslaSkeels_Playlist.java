package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;

public class TeslaSkeels_Playlist {
	
	//added songs from Flor and TomGrennan
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException
	{
		//Create a linked list called playlist of type PlayableSong
		LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();

		ArrayList<Song> florTracks = new ArrayList<Song>();
	    Flor florBand = new Flor();	
	    florTracks = florBand.getFlorSongs();
		playlist.add(florTracks.get(0));
		playlist.add(florTracks.get(1));
		ArrayList<Song> tomGrennanTracks = new ArrayList<Song>();
	    TomGrennan tomGrennanBand = new TomGrennan();
	    tomGrennanTracks = tomGrennanBand.getTomGrennanSongs();
		playlist.add(tomGrennanTracks.get(0));
		playlist.add(tomGrennanTracks.get(1));
		playlist.add(tomGrennanTracks.get(2));

	    return playlist;
	}
	
}
