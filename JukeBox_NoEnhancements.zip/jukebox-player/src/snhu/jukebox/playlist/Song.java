package snhu.jukebox.playlist;
import java.net.URISyntaxException;


public class Song extends PlayableSong {

	//Creating a song object
    public Song(String t, String a){
        this.title = t;
        this.artist = a;

    }
    

    @Override
    void play() {
        System.out.println("Now playing " + this.title + " by " + this.artist + ".");

	}	
}
