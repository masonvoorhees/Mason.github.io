package snhu.jukebox.playlist;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;

public class JukeboxPlayer {
         
    public static void main(String[] args) {
        
    	try{
    		String studentPlaylistRequested ="";                             
    	    Queue<PlayableSong> playlist = new LinkedList<PlayableSong>();		
    		Jukebox jukebox = new Jukebox();          							
			CommandManager cm=new CommandManager();   						
			
	
			while(true){
				cm.printMainMenu();                                     	
				String command = cm.getCommand();                       		
				if(command.toLowerCase().equals("quit")) 
				{
					System.out.println("Session ended");
					break; 
				}																
				studentPlaylistRequested = cm.parseCommand(command);    		
    		
				playlist = jukebox.play(studentPlaylistRequested);             
				int playlistSize = playlist.size();								

					jukebox.playNext();

			
			}

    	}
    	
    	catch(Exception e){
			System.out.println("An error has occured.");

		}

    	

}
}