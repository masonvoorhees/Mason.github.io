package snhu.jukebox.playlist;

import snhu.student.playlists.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class StudentList {

	public StudentList(){
	}

	public List<String> getStudentsNames() {
		ArrayList<String> studentNames = new ArrayList<String>();
		
		String StudentName1 = "TestStudent1Name";
		studentNames.add(StudentName1);

		String StudentName2 = "TestStudent2Name";
		studentNames.add(StudentName2);
		
		String StudentName3 = "Philip Enkema";			
		studentNames.add(StudentName3);
		
		//Add Student Name 'Troy Smith' //
		String StudentName4 = "Troy Smith";			
		studentNames.add(StudentName4);
		
		//Add Student Name RobertChandler
		String StudentName5 = "Robert Chandler";			
		studentNames.add(StudentName5);

		String StudentName6 = "Samir Ragih";
		studentNames.add(StudentName6);
		
		String StudentName7 = "Tesla Skeels";
		studentNames.add(StudentName7);
		
		String StudentName8 = "Ananda Magar";
		studentNames.add(StudentName8);
		
		//Add Student Name Mason Voorhees
		String StudentName9 = "Mason Voorhees";
		studentNames.add(StudentName9);
		
		String StudentName10 = "Nicholas Aguirre";
		studentNames.add(StudentName10);

		
		String StudentName12 = "TestStudent2Name";
		studentNames.add(StudentName12);

		
		return studentNames;
	}

	public Student GetStudentProfile(String student) throws URISyntaxException{
		Student emptyStudent = null;
	
		switch(student) {
		   //Add a case statement for my profile "Test Student 1"  
		   case "TestStudent1_Playlist":
			   TestStudent1_Playlist testStudent1Playlist = new TestStudent1_Playlist();
			   Student TestStudent1 = new Student("TestStudent1", testStudent1Playlist.StudentPlaylist());
			   return TestStudent1;
			   
			   //Add a case statement for my profile "Phillip Enkema"  
		   case "PhilipEnkema_Playlist":
			   PhilipEnkema_Playlist philipEnkema_Playlist = new PhilipEnkema_Playlist();
			   Student PhilipEnkema = new Student("Philip Enkema", philipEnkema_Playlist.StudentPlaylist());
			   return PhilipEnkema;
			   
		   //Add a case statement for my profile "Ananda Magar"   
		   case "AnandaMagar_Playlist":
			   AnandaMagar_Playlist anandaMagar_Playlist = new AnandaMagar_Playlist();
			   Student AnandaMagar = new Student("Ananda Magar", anandaMagar_Playlist.StudentPlaylist());
			   return AnandaMagar;
			   
			   //Add a case statement for my profile "Mason Voorhees"   
		   case "MasonVoorhees_Playlist":
			   MasonVoorhees_Playlist masonVoorhees_Playlist = new MasonVoorhees_Playlist();
			   Student MasonVoorhees = new Student("Mason Voorhees", masonVoorhees_Playlist.StudentPlaylist());
			   return MasonVoorhees;
			   //Add a case statement for my profile "Create paylist"  
			   //Add a case statement for my profile "Tesla Skeels"  
		   case "TeslaSkeels_Playlist":
			   TeslaSkeels_Playlist teslaSkeels_Playlist = new TeslaSkeels_Playlist();
			   Student TeslaSkeels = new Student("Tesla Skeels", teslaSkeels_Playlist.StudentPlaylist());
			   return TeslaSkeels;
			   //Add a case statement for my profile "Test Student2"  
		   case "TestStudent2_Playlist":
			   TestStudent2_Playlist testStudent2Playlist = new TestStudent2_Playlist();
			   Student TestStudent2 = new Student("TestStudent2", testStudent2Playlist.StudentPlaylist());
			   return TestStudent2;
		}
		return emptyStudent;
	}
}
