package music.artist;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class Adele {

	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Adele() {
    }
    
    public ArrayList<Song> getAdelesSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 
		 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("Oh my god", "Adele");           				
         Song track2 = new Song("Easy On Me", "Adele");                    				
         Song track3 = new Song("30", "Adele");   
         Song track4 = new Song("To Be Loved", "Adele");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                               //Return the songs for Adele in the form of an ArrayList
    }
}