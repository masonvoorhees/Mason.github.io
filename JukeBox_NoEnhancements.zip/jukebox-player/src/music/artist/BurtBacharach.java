package music.artist;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class BurtBacharach {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public BurtBacharach() {
    }
    
    public ArrayList<Song> getBurtBacharachSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  

		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("What The Wrold Needs Nows", "Burt Bacharach");           				
         Song track2 = new Song("I'll Never Love This Way Again", "Burt Bacharach");                    				
         Song track3 = new Song("Walk On By", "Burt Bacharach");   
         Song track4 = new Song("Then Come You", "Burt Bacharach");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                        		//Return the songs for Burt Bacharach in the form of an ArrayList
    }
}
