package music.artist;

import snhu.jukebox.playlist.Song;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URI;
import java.util.ArrayList;
//Created by Mason Voorhees
public class PopSmoke {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public PopSmoke() {
    }
    
    public ArrayList<Song> getPopSmokeSongs() throws URISyntaxException {
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
		 

    	 Song track1 = new Song("What You Know Bout Love", "Pop Smoke");           				
         Song track2 = new Song("Mood Swings", "Pop Smoke");                    				
         Song track3 = new Song("Element", "Pop Smoke");   
         Song track4 = new Song("Hello", "Pop Smoke");
         

         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                  						  //Return the songs for the Pop Smoke in the form of an ArrayList
         
    }
}
