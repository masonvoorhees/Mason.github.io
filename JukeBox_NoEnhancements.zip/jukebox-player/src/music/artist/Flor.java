package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class Flor {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Flor() {
    }
    
    public ArrayList<Song> getFlorSongs() throws URISyntaxException {
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 
    	 //Instantiate the album so we can populate it below
    	 Song track1 = new Song("Imho", "Flor");        
         Song track2 = new Song("get behind this", "Flor");        
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                     
         this.albumTracks.add(track2);                                        
         return albumTracks;                                                  

    }
}
