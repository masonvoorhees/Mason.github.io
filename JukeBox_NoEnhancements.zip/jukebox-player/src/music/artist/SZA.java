package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class SZA {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public SZA() {
    }
    
    public ArrayList<Song> getSzaSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  

		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("I Hate You", "SZA");           				
         Song track2 = new Song("All The Stars", "SZA");                    				
         Song track3 = new Song("Good Days", "SZA");   
         Song track4 = new Song("No Love", "SZA");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                       //Return the songs for the Surfaces in the form of an ArrayList
    }
}
