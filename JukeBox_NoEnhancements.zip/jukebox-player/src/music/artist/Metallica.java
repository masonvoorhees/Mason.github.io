package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class Metallica {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public Metallica() {
    }
    
    public ArrayList<Song> getMetallicaSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 
		 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("Enter Sandman", "Metallica");           				
         Song track2 = new Song("One", "Metallica");                    				
         Song track3 = new Song("Whisley In My Jar", "Metallica");   
         Song track4 = new Song("Master of Puppets", "Metallica");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                        //Return the songs for Metallica in the form of an ArrayList
    }
}
