package music.artist;

import snhu.jukebox.playlist.Song;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class TheBeatles {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public TheBeatles() {
    }
    
    public ArrayList<Song> getBeatlesSongs() throws URISyntaxException {
    	
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  

		 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("Let It Be", "The Beatles");           				
         Song track2 = new Song("Come Together", "The Beatles");                    				
         Song track3 = new Song("Hey Jude", "The Beatles");   
         Song track4 = new Song("Something", "The Beatles");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                                        //Return the songs for the Beatles in the form of an ArrayList
    }
}
