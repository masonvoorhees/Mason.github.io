package music.artist;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import snhu.jukebox.playlist.Song;

public class HerbAlpert {
	
	ArrayList<Song> albumTracks;
    String albumTitle;
    
    public HerbAlpert() {
    }
    
    public ArrayList<Song> getHerbAlpertSongs() throws URISyntaxException {
    	
    	//Create albumTrack array list to put all the songs into 
    	 albumTracks = new ArrayList<Song>();  
    	 
		 
		 //Create a song object with title, name, and trackLink
    	 Song track1 = new Song("Rise", "Herb Albert","https://www.youtube.com/watch?v=q7O3eYJptTc");           				
         Song track2 = new Song("Route 101", "Herb Albert","https://www.youtube.com/watch?v=7GCLdCu2vm4");                    				
         Song track3 = new Song("Spanish Flea", "Herb Albert","https://www.youtube.com/watch?v=aBE9EQ7gXKI");   
         Song track4 = new Song("LadyFingers", "Herb Albert ","https://www.youtube.com/watch?v=l6U1JB7z-I8");
         
         //Add all songs to the albumTracks arrayList
         this.albumTracks.add(track1);                                          				
         this.albumTracks.add(track2);                                          	
         this.albumTracks.add(track3);
         this.albumTracks.add(track4);
         
         //Return the albumTracks array list
         return albumTracks;                                       //Return the songs for Burt Bacharach in the form of an ArrayList
    }
}
