package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedList;
//Created by Mason Voorhees
public class Create_Playlist {
	//user can create their own playlist
    
	public LinkedList<PlayableSong> StudentPlaylist() throws URISyntaxException{
	
	// Create a new Linked list of type playableSong
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	//Create an array list of type song 
	ArrayList<Song> userPlaylistTracks = new ArrayList<Song>();
	
	//instantiate userplaylist from UserPlaylist
	UserPlaylist userPlaylist = new UserPlaylist();
	
	userPlaylistTracks = userPlaylist.createAPlaylist();
	
	//loop through the user created playlist and add it to the linked list 
	for(int i = 0;i<userPlaylistTracks.size();i++)
	{
		playlist.add(userPlaylistTracks.get(i));
	}


	//return the playlist with all added songs
    return playlist;
	}
}
